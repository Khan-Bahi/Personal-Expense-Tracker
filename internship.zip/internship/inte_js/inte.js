let expenses = [];

function addExpense() {
    let title = document.getElementById("title").value;
    let amount = document.getElementById("amount").value;
    let category = document.getElementById("category").value;

    if (title === "" || amount === "") {
        alert("Please fill all fields");
        return;
    }

    expenses.push({
        title: title,
        amount: parseFloat(amount),
        category: category
    });

    document.getElementById("title").value = "";
    document.getElementById("amount").value = "";

    render();
}

function render() {
    let list = document.getElementById("list");
    list.innerHTML = "";

    let total = 0;

    expenses.forEach((e, index) => {
        total += e.amount;

        list.innerHTML += `
            <tr>
                <td>${e.title}</td>
                <td>${e.amount}</td>
                <td>${e.category}</td>
                <td>
                    <button class="delete-btn" onclick="deleteExpense(${index})">
                        Delete
                    </button>
                </td>
            </tr>
        `;
    });

    document.getElementById("totalBox").innerText = "Total: " + total;
}

function deleteExpense(index) {
    expenses.splice(index, 1);
    render();
}